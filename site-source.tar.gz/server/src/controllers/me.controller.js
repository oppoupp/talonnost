import { z } from "zod";
import { httpError } from "../lib/http.js";
import { bookSchema } from "../models/appointments.model.js";
import { bookAppointment, cancelAppointment } from "../repositories/appointments.repo.js";
import { readDb } from "../models/db.js";

export async function getMe(req, res, next) {
  try {
    const db = await readDb();
    const me = db.users.find((u) => u.id === req.userId);
    if (!me) return next(httpError(401, "UNAUTHORIZED", "Пользователь не найден"));
    res.json({ ok: true, user: { id: me.id, username: me.username, email: me.email } });
  } catch (e) {
    next(e);
  }
}

export async function myAppointments(req, res, next) {
  try {
    const db = await readDb();
    const doctorsById = new Map(db.doctors.map((d) => [d.id, d]));
    const clinicsById = new Map(db.clinics.map((c) => [c.id, c]));

    const mine = db.appointments
      .filter((a) => a.user_id === req.userId)
      .sort((a, b) => new Date(a.slot_time) - new Date(b.slot_time))
      .map((a) => {
        const doctor = doctorsById.get(a.doctor_id);
        const clinic = doctor ? clinicsById.get(doctor.clinic_id) : null;
        return { ...a, doctor, clinic };
      });

    res.json({ ok: true, appointments: mine });
  } catch (e) {
    next(e);
  }
}

export async function book(req, res, next) {
  try {
    const parsed = bookSchema.safeParse(req.body);
    if (!parsed.success) {
      return next(
        httpError(400, "VALIDATION_ERROR", "Проверьте выбор слота", parsed.error.flatten())
      );
    }
    const appt = await bookAppointment({ appointmentId: parsed.data.appointmentId, userId: req.userId });
    res.json({ ok: true, appointment: appt });
  } catch (e) {
    next(e);
  }
}

export async function cancel(req, res, next) {
  try {
    const schema = z.object({ appointmentId: z.string().min(1) });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) {
      return next(
        httpError(400, "VALIDATION_ERROR", "Проверьте выбор записи", parsed.error.flatten())
      );
    }
    const appt = await cancelAppointment({ appointmentId: parsed.data.appointmentId, userId: req.userId });
    res.json({ ok: true, appointment: appt });
  } catch (e) {
    next(e);
  }
}

