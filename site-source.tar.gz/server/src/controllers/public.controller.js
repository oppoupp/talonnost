import { listAppointments, listClinics, listDoctors } from "../repositories/public.repo.js";

function normalize(s) {
  return String(s || "")
    .trim()
    .toLowerCase();
}

function timeBucket(iso) {
  const d = new Date(iso);
  const h = d.getHours();
  if (h < 12) return "morning";
  if (h < 17) return "day";
  return "evening";
}

export async function search(req, res, next) {
  try {
    const q = normalize(req.query.q);
    const district = normalize(req.query.district);
    const clinicType = normalize(req.query.clinicType); // state | private
    const bucket = normalize(req.query.time); // morning | day | evening

    const [clinics, doctors, appointments] = await Promise.all([
      listClinics(),
      listDoctors(),
      listAppointments()
    ]);

    const clinicsById = new Map(clinics.map((c) => [c.id, c]));

    let filteredDoctors = doctors;
    if (q) {
      filteredDoctors = filteredDoctors.filter((d) => normalize(d.specialty).includes(q));
    }

    if (district) {
      filteredDoctors = filteredDoctors.filter((d) => {
        const clinic = clinicsById.get(d.clinic_id);
        return clinic ? normalize(clinic.district).includes(district) : false;
      });
    }

    if (clinicType === "state" || clinicType === "private") {
      filteredDoctors = filteredDoctors.filter((d) => {
        const clinic = clinicsById.get(d.clinic_id);
        return clinic ? clinic.type === clinicType : false;
      });
    }

    const doctorIds = new Set(filteredDoctors.map((d) => d.id));

    let slots = appointments.filter((a) => doctorIds.has(a.doctor_id) && a.status === "available");
    if (bucket) {
      slots = slots.filter((a) => timeBucket(a.slot_time) === bucket);
    }

    res.json({
      ok: true,
      doctors: filteredDoctors,
      clinics,
      availableSlots: slots
    });
  } catch (e) {
    next(e);
  }
}

export async function clinics(req, res, next) {
  try {
    const clinics = await listClinics();
    res.json({ ok: true, clinics });
  } catch (e) {
    next(e);
  }
}

export async function doctors(req, res, next) {
  try {
    const doctors = await listDoctors();
    res.json({ ok: true, doctors });
  } catch (e) {
    next(e);
  }
}

