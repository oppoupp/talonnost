import { createUser, loginUser, registerSchema, loginSchema } from "../models/users.model.js";
import { httpError } from "../lib/http.js";

export async function register(req, res, next) {
  try {
    const parsed = registerSchema.safeParse(req.body);
    if (!parsed.success) {
      return next(
        httpError(400, "VALIDATION_ERROR", "Проверьте поля формы", parsed.error.flatten())
      );
    }

    const result = await createUser(parsed.data);
    res.json({ ok: true, ...result });
  } catch (e) {
    next(e);
  }
}

export async function login(req, res, next) {
  try {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) {
      return next(
        httpError(400, "VALIDATION_ERROR", "Проверьте поля формы", parsed.error.flatten())
      );
    }

    const result = await loginUser(parsed.data);
    res.json({ ok: true, ...result });
  } catch (e) {
    next(e);
  }
}

