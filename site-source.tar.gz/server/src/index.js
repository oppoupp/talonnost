import path from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";

import { router as authRouter } from "./routes/auth.routes.js";
import { router as publicRouter } from "./routes/public.routes.js";
import { router as meRouter } from "./routes/me.routes.js";

const app = express();

app.use(helmet());
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: "1mb" }));
app.use(morgan("dev"));

app.get("/api/health", (req, res) => {
  res.json({ ok: true, service: "talonnost-server" });
});

app.use("/api/auth", authRouter);
app.use("/api", publicRouter);
app.use("/api/me", meRouter);

const clientDist = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../client/dist");
app.use(express.static(clientDist));
app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(clientDist, "index.html"));
});

// Централизованная обработка ошибок
// Важно: возвращаем понятные сообщения для UX (toast) и отладки.
app.use((err, req, res, next) => {
  const status = err?.status || 500;
  const code = err?.code || "INTERNAL_ERROR";
  const message = err?.message || "Внутренняя ошибка сервера";
  const details = err?.details;

  res.status(status).json({
    ok: false,
    error: { code, message, details }
  });
});

const PORT = process.env.PORT ? Number(process.env.PORT) : 4000;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`API listening on http://localhost:${PORT}`);
});

