import { readDb } from "./db.js";

export async function listClinics() {
  const db = await readDb();
  return db.clinics;
}

export async function listDoctors() {
  const db = await readDb();
  return db.doctors;
}

export async function listAppointments() {
  const db = await readDb();
  return db.appointments;
}

