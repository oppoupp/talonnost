import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { z } from "zod";
import { httpError } from "../lib/http.js";
import { newId, updateDb } from "./db.js";

const JWT_SECRET = process.env.JWT_SECRET || "dev_secret_change_me";
const TOKEN_TTL = "7d";

export const registerSchema = z.object({
  username: z.string().min(2).max(32),
  email: z.string().email(),
  password: z.string().min(8).max(128)
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1)
});

function signToken(user) {
  return jwt.sign({ sub: user.id }, JWT_SECRET, { expiresIn: TOKEN_TTL });
}

export async function createUser({ username, email, password }) {
  return updateDb(async (db) => {
    const exists = db.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (exists) throw httpError(409, "EMAIL_TAKEN", "Этот email уже зарегистрирован");

    const password_hash = await bcrypt.hash(password, 10);
    const user = {
      id: newId("usr"),
      username,
      email,
      password_hash
    };
    db.users.push(user);
    return {
      user: { id: user.id, username: user.username, email: user.email },
      token: signToken(user)
    };
  });
}

export async function loginUser({ email, password }) {
  return updateDb(async (db) => {
    const user = db.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!user) throw httpError(401, "INVALID_CREDENTIALS", "Неверный email или пароль");

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) throw httpError(401, "INVALID_CREDENTIALS", "Неверный email или пароль");

    return {
      user: { id: user.id, username: user.username, email: user.email },
      token: signToken(user)
    };
  });
}

export function verifyToken(token) {
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    return payload?.sub;
  } catch {
    return null;
  }
}

