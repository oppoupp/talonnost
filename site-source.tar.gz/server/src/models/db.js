import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createMutex } from "../lib/mutex.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataPath = path.resolve(__dirname, "..", "data", "data.json");

const withLock = createMutex();

export async function readDb() {
  const raw = await fs.readFile(dataPath, "utf8");
  return JSON.parse(raw);
}

export async function writeDb(next) {
  await fs.writeFile(dataPath, JSON.stringify(next, null, 2), "utf8");
}

export async function updateDb(mutator) {
  return withLock(async () => {
    const db = await readDb();
    const result = await mutator(db);
    await writeDb(db);
    return result;
  });
}

export function newId(prefix = "id") {
  return `${prefix}_${Math.random().toString(16).slice(2)}${Date.now().toString(16)}`;
}

