import { Router } from "express";
import { clinics, doctors, search } from "../controllers/public.controller.js";

export const router = Router();

router.get("/search", search);
router.get("/clinics", clinics);
router.get("/doctors", doctors);

