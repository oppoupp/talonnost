import { Router } from "express";
import { requireAuth } from "../middlewares/auth.js";
import { book, cancel, getMe, myAppointments } from "../controllers/me.controller.js";

export const router = Router();

router.use(requireAuth);
router.get("/", getMe);
router.get("/appointments", myAppointments);
router.post("/appointments/book", book);
router.post("/appointments/cancel", cancel);

