import { Router } from "express";
import { login, register } from "../controllers/auth.controller.js";

export const router = Router();

// API авторизации
router.post("/register", register);
router.post("/login", login);

