import { httpError } from "../lib/http.js";
import { updateDb } from "../models/db.js";

// Репозиторий записи (MVP).
// В реальной БД “слот занят” будет обеспечиваться уникальными ограничениями/транзакцией.

export async function bookAppointment({ appointmentId, userId }) {
  return updateDb(async (db) => {
    const appt = db.appointments.find((a) => a.id === appointmentId);
    if (!appt) throw httpError(404, "NOT_FOUND", "Слот не найден");

    if (appt.status === "booked") {
      throw httpError(409, "SLOT_TAKEN", "Слот уже занят. Выберите другое время.");
    }

    appt.status = "booked";
    appt.user_id = userId;
    return appt;
  });
}

export async function cancelAppointment({ appointmentId, userId }) {
  return updateDb(async (db) => {
    const appt = db.appointments.find((a) => a.id === appointmentId);
    if (!appt) throw httpError(404, "NOT_FOUND", "Запись не найдена");
    if (appt.user_id !== userId) throw httpError(403, "FORBIDDEN", "Нет доступа к этой записи");

    appt.status = "available";
    appt.user_id = null;
    return appt;
  });
}

