import { readDb } from "../models/db.js";

// Репозиторий данных (MVP).
// Сейчас — адаптер над data.json. Позже можно заменить реализацию на Prisma/Sequelize,
// сохранив контракт методов и не трогая контроллеры.

export async function listClinics() {
  const db = await readDb();
  return db.clinics;
}

export async function listDoctors() {
  const db = await readDb();
  return db.doctors;
}

export async function listAppointments() {
  const db = await readDb();
  return db.appointments;
}

