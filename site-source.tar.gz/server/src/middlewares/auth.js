import { httpError } from "../lib/http.js";
import { verifyToken } from "../models/users.model.js";

export function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice("Bearer ".length) : null;
  if (!token) return next(httpError(401, "UNAUTHORIZED", "Требуется авторизация"));

  const userId = verifyToken(token);
  if (!userId) return next(httpError(401, "UNAUTHORIZED", "Токен недействителен"));

  req.userId = userId;
  next();
}

