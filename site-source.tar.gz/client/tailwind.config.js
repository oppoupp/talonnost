/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      fontSize: {
        base: "18px"
      },
      colors: {
        primary: {
          600: "#2563eb"
        }
      }
    }
  },
  plugins: []
};

