import { create } from "zustand";
import { api, setAuthToken } from "../services/api";

const LS_KEY = "talonnost_auth";

function load() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function save(state) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(state));
  } catch {
    // ignore
  }
}

const initial = load() || { token: null, user: null };
setAuthToken(initial.token);

export const useAuthStore = create((set, get) => ({
  token: initial.token,
  user: initial.user,
  authLoading: false,

  hydrate: async () => {
    const { token } = get();
    if (!token) return;
    set({ authLoading: true });
    try {
      const { data } = await api.get("/me");
      if (data?.ok) {
        set({ user: data.user });
        save({ token, user: data.user });
      }
    } finally {
      set({ authLoading: false });
    }
  },

  register: async ({ username, email, password }) => {
    set({ authLoading: true });
    try {
      const { data } = await api.post("/auth/register", { username, email, password });
      if (data?.ok) {
        setAuthToken(data.token);
        set({ token: data.token, user: data.user });
        save({ token: data.token, user: data.user });
        return { ok: true };
      }
      return { ok: false };
    } finally {
      set({ authLoading: false });
    }
  },

  login: async ({ email, password }) => {
    set({ authLoading: true });
    try {
      const { data } = await api.post("/auth/login", { email, password });
      if (data?.ok) {
        setAuthToken(data.token);
        set({ token: data.token, user: data.user });
        save({ token: data.token, user: data.user });
        return { ok: true };
      }
      return { ok: false };
    } finally {
      set({ authLoading: false });
    }
  },

  logout: () => {
    setAuthToken(null);
    set({ token: null, user: null });
    save({ token: null, user: null });
  }
}));

