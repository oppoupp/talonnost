import { create } from "zustand";

export const useAppStore = create((set) => ({
  route: "home", // home | account
  setRoute: (route) => set({ route })
}));

