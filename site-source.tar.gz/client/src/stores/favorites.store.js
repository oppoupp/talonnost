import { create } from "zustand";

const LS_KEY = "talonnost_favorites";

function load() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function save(ids) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(ids));
  } catch {
    // ignore
  }
}

export const useFavoritesStore = create((set, get) => ({
  doctorIds: load(),
  has: (doctorId) => get().doctorIds.includes(doctorId),
  toggle: (doctorId) => {
    const prev = get().doctorIds;
    const next = prev.includes(doctorId) ? prev.filter((id) => id !== doctorId) : [doctorId, ...prev];
    save(next);
    set({ doctorIds: next });
  },
  clear: () => {
    save([]);
    set({ doctorIds: [] });
  }
}));

