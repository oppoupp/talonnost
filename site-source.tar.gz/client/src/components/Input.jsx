import React from "react";

export function Input({ label, hint, error, className = "", id, ...props }) {
  const inputId = id || props.name;
  const describedBy = error ? `${inputId}-error` : hint ? `${inputId}-hint` : undefined;

  return (
    <div className={className}>
      {label ? (
        <label htmlFor={inputId} className="mb-1 block text-sm font-medium text-slate-700">
          {label}
        </label>
      ) : null}
      <input
        id={inputId}
        aria-invalid={error ? "true" : "false"}
        aria-describedby={describedBy}
        className={
          "w-full rounded-xl border bg-white px-4 py-3 text-base outline-none " +
          "border-slate-200 focus:ring-2 focus:ring-primary-600 focus:ring-offset-2 " +
          (error ? "border-rose-300 focus:ring-rose-500" : "")
        }
        {...props}
      />
      {hint && !error ? (
        <p id={`${inputId}-hint`} className="mt-1 text-sm text-slate-500">
          {hint}
        </p>
      ) : null}
      {error ? (
        <p id={`${inputId}-error`} className="mt-1 text-sm text-rose-700">
          {error}
        </p>
      ) : null}
    </div>
  );
}

