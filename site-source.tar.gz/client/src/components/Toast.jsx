import React, { createContext, useCallback, useContext, useMemo, useState } from "react";

const ToastCtx = createContext(null);

function uid() {
  return `${Math.random().toString(16).slice(2)}${Date.now().toString(16)}`;
}

export function ToastProvider({ children }) {
  const [items, setItems] = useState([]);

  const push = useCallback((toast) => {
    const id = uid();
    const next = {
      id,
      type: toast.type || "info", // info | success | error
      title: toast.title,
      message: toast.message,
      timeoutMs: toast.timeoutMs ?? 3500
    };
    setItems((prev) => [next, ...prev]);
    if (next.timeoutMs) {
      window.setTimeout(() => {
        setItems((prev) => prev.filter((t) => t.id !== id));
      }, next.timeoutMs);
    }
  }, []);

  const api = useMemo(() => ({ push }), [push]);

  return (
    <ToastCtx.Provider value={api}>
      {children}
      <div className="fixed right-4 top-4 z-[60] flex w-[min(420px,calc(100vw-2rem))] flex-col gap-2">
        {items.map((t) => (
          <div
            key={t.id}
            role="status"
            className={
              "rounded-2xl border bg-white px-4 py-3 shadow-lg " +
              (t.type === "success"
                ? "border-emerald-200"
                : t.type === "error"
                  ? "border-rose-200"
                  : "border-slate-200")
            }
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                {t.title ? <div className="text-sm font-semibold">{t.title}</div> : null}
                {t.message ? <div className="text-sm text-slate-700">{t.message}</div> : null}
              </div>
              <button
                type="button"
                className="min-h-[44px] min-w-[44px] rounded-xl hover:bg-slate-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-600 focus-visible:ring-offset-2"
                onClick={() => setItems((prev) => prev.filter((x) => x.id !== t.id))}
                aria-label="Закрыть уведомление"
              >
                ✕
              </button>
            </div>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastCtx);
  if (!ctx) throw new Error("useToast must be used within ToastProvider");
  return ctx;
}

