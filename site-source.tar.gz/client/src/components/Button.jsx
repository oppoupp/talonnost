import React from "react";

const base =
  "inline-flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-base font-medium " +
  "transition focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-600 focus-visible:ring-offset-2 " +
  "disabled:opacity-50 disabled:cursor-not-allowed select-none";

const variants = {
  primary: "bg-primary-600 text-white hover:bg-blue-700 active:bg-blue-800",
  secondary: "bg-white text-slate-900 border border-slate-200 hover:bg-slate-50 active:bg-slate-100",
  ghost: "bg-transparent text-slate-900 hover:bg-slate-100 active:bg-slate-200",
  danger: "bg-rose-600 text-white hover:bg-rose-700 active:bg-rose-800"
};

export function Button({
  as: Comp = "button",
  variant = "primary",
  className = "",
  ...props
}) {
  const cls = `${base} ${variants[variant] || variants.primary} ${className}`.trim();
  return <Comp className={cls} {...props} />;
}

