import React, { useEffect } from "react";
import { useAppStore } from "../stores/app.store";
import { useAuthStore } from "../stores/auth.store";
import { Button } from "./Button";

export function Layout({ children }) {
  const route = useAppStore((s) => s.route);
  const setRoute = useAppStore((s) => s.setRoute);
  const user = useAuthStore((s) => s.user);
  const hydrate = useAuthStore((s) => s.hydrate);
  const logout = useAuthStore((s) => s.logout);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  return (
    <div className="min-h-screen">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[70] focus:rounded-xl focus:bg-white focus:px-4 focus:py-3 focus:shadow"
      >
        Перейти к содержимому
      </a>

      <header className="border-b border-slate-200 bg-white">
        <nav className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-primary-600 text-white">
              Т
            </div>
            <div>
              <div className="text-base font-semibold leading-tight">Талонность.ру</div>
              <div className="text-sm text-slate-500 leading-tight">Запись к врачу за 3 клика</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant={route === "home" ? "primary" : "secondary"}
              onClick={() => setRoute("home")}
              className="min-h-[44px]"
              type="button"
            >
              Поиск
            </Button>
            <Button
              variant={route === "account" ? "primary" : "secondary"}
              onClick={() => setRoute("account")}
              className="min-h-[44px]"
              type="button"
            >
              Кабинет
            </Button>
            {user ? (
              <Button
                variant="ghost"
                onClick={logout}
                className="min-h-[44px]"
                type="button"
              >
                Выйти
              </Button>
            ) : null}
          </div>
        </nav>
      </header>

      <main id="main" className="mx-auto max-w-6xl px-4 py-6">
        {children}
      </main>
    </div>
  );
}

