import React from "react";
import { Layout } from "../components/Layout";
import { ToastProvider } from "../components/Toast";
import { useOnline } from "../hooks/useOnline";
import { useAppStore } from "../stores/app.store";
import { HomePage } from "../features/Search/HomePage";
import { AccountPage } from "../features/Account/AccountPage";

export function App() {
  const online = useOnline();
  const route = useAppStore((s) => s.route);

  return (
    <ToastProvider>
      <Layout>
        {!online ? (
          <div
            role="status"
            className="mb-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900"
          >
            Нет интернета. Вы можете просматривать данные, но запись может не сработать.
          </div>
        ) : null}

        {route === "home" ? <HomePage /> : null}
        {route === "account" ? <AccountPage /> : null}
      </Layout>
    </ToastProvider>
  );
}

