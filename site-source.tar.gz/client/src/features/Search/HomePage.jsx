import React, { useEffect, useMemo, useState } from "react";
import { Card } from "../../components/Card";
import { Input } from "../../components/Input";
import { Button } from "../../components/Button";
import { useToast } from "../../components/Toast";
import { searchDoctors } from "./search.service";
import { DoctorCard } from "./components/DoctorCard";
import { BookingModal } from "../Booking/BookingModal";
import { ClinicMap } from "./components/ClinicMap";
import { useFavoritesStore } from "../../stores/favorites.store";

function byTimeAsc(a, b) {
  return new Date(a) - new Date(b);
}

export function HomePage() {
  const toast = useToast();
  const favoriteIds = useFavoritesStore((s) => s.doctorIds);

  const [q, setQ] = useState("Кардиолог");
  const [district, setDistrict] = useState("");
  const [clinicType, setClinicType] = useState("");
  const [time, setTime] = useState("");
  const [sort, setSort] = useState("rating"); // rating | experience | soonest
  const [onlyFav, setOnlyFav] = useState(false);

  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);

  const [selectedDoctorId, setSelectedDoctorId] = useState(null);

  const selectedDoctor = useMemo(() => {
    if (!data?.doctors?.length) return null;
    return data.doctors.find((d) => d.id === selectedDoctorId) || null;
  }, [data, selectedDoctorId]);

  const selectedSlots = useMemo(() => {
    if (!selectedDoctor || !data?.availableSlots) return [];
    return data.availableSlots.filter((s) => s.doctor_id === selectedDoctor.id);
  }, [data, selectedDoctor]);

  const districts = useMemo(() => {
    const list = (data?.clinics || [])
      .map((c) => c.district)
      .filter(Boolean);
    const uniq = Array.from(new Set(list));
    uniq.sort((a, b) => a.localeCompare(b, "ru"));
    return ["", ...uniq];
  }, [data]);

  const clinicsById = useMemo(() => {
    const m = new Map();
    for (const c of data?.clinics || []) m.set(c.id, c);
    return m;
  }, [data]);

  const soonestSlotByDoctor = useMemo(() => {
    const m = new Map();
    for (const s of data?.availableSlots || []) {
      const prev = m.get(s.doctor_id);
      if (!prev || new Date(s.slot_time) < new Date(prev)) m.set(s.doctor_id, s.slot_time);
    }
    return m;
  }, [data]);

  const visibleDoctors = useMemo(() => {
    const list = (data?.doctors || []).slice();
    const filtered = onlyFav ? list.filter((d) => favoriteIds.includes(d.id)) : list;

    filtered.sort((a, b) => {
      if (sort === "experience") return (b.experience || 0) - (a.experience || 0);
      if (sort === "soonest") {
        const at = soonestSlotByDoctor.get(a.id);
        const bt = soonestSlotByDoctor.get(b.id);
        if (!at && !bt) return 0;
        if (!at) return 1;
        if (!bt) return -1;
        return byTimeAsc(at, bt);
      }
      // rating (по рейтингу клиники)
      const ar = clinicsById.get(a.clinic_id)?.rating ?? 0;
      const br = clinicsById.get(b.clinic_id)?.rating ?? 0;
      return br - ar;
    });

    return filtered;
  }, [data, onlyFav, favoriteIds, sort, clinicsById, soonestSlotByDoctor]);

  async function runSearch() {
    setLoading(true);
    try {
      const res = await searchDoctors({ q, district, clinicType, time });
      setData(res);
      if (res?.ok && res.doctors?.length === 0) {
        toast.push({ type: "info", title: "Ничего не найдено", message: "Попробуйте изменить фильтры" });
      }
    } catch (err) {
      toast.push({
        type: "error",
        title: "Ошибка поиска",
        message: err?.response?.data?.error?.message || "Не удалось загрузить данные"
      });
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    runSearch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <section className="space-y-4">
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
            <Input
              label="Специальность"
              name="specialty"
              placeholder="Например: Кардиолог"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              className="flex-1"
            />
            <Button
              type="button"
              onClick={runSearch}
              disabled={loading}
              className="min-h-[44px] sm:w-auto"
            >
              {loading ? "Ищем…" : "Найти"}
            </Button>
          </div>

          <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-3">
            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Район</label>
              <select
                className="min-h-[44px] w-full rounded-xl border border-slate-200 bg-white px-4 py-3"
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
              >
                {districts.map((d) => (
                  <option key={d} value={d}>
                    {d || "Любой"}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Тип клиники</label>
              <select
                className="min-h-[44px] w-full rounded-xl border border-slate-200 bg-white px-4 py-3"
                value={clinicType}
                onChange={(e) => setClinicType(e.target.value)}
              >
                <option value="">Любой</option>
                <option value="state">Гос</option>
                <option value="private">Частная</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Время</label>
              <select
                className="min-h-[44px] w-full rounded-xl border border-slate-200 bg-white px-4 py-3"
                value={time}
                onChange={(e) => setTime(e.target.value)}
              >
                <option value="">Любое</option>
                <option value="morning">Утро</option>
                <option value="day">День</option>
                <option value="evening">Вечер</option>
              </select>
            </div>
          </div>

          <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-3">
            <div className="md:col-span-2">
              <label className="mb-1 block text-sm font-medium text-slate-700">Сортировка</label>
              <select
                className="min-h-[44px] w-full rounded-xl border border-slate-200 bg-white px-4 py-3"
                value={sort}
                onChange={(e) => setSort(e.target.value)}
              >
                <option value="rating">По рейтингу клиники</option>
                <option value="experience">По стажу врача</option>
                <option value="soonest">По ближайшему слоту</option>
              </select>
            </div>
            <div className="flex items-end">
              <label className="flex min-h-[44px] w-full cursor-pointer items-center gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3">
                <input
                  type="checkbox"
                  className="h-5 w-5"
                  checked={onlyFav}
                  onChange={(e) => setOnlyFav(e.target.checked)}
                />
                <span className="text-sm font-medium text-slate-700">Только избранные</span>
              </label>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            <Button variant="secondary" type="button" onClick={runSearch} disabled={loading}>
              Применить фильтры
            </Button>
            <Button
              variant="ghost"
              type="button"
              onClick={() => {
                setDistrict("");
                setClinicType("");
                setTime("");
              }}
            >
              Сбросить
            </Button>
          </div>
        </Card>

        <Card className="min-h-[360px] lg:row-span-2">
          <div className="mb-2 text-base font-semibold">Карта клиник</div>
          <div className="h-[320px] overflow-hidden rounded-2xl border border-slate-200">
            <ClinicMap clinics={data?.clinics || []} />
          </div>
          <div className="mt-2 text-sm text-slate-500">
            Нажмите на маркер, чтобы увидеть название и рейтинг.
          </div>
        </Card>
      </div>

      <section aria-label="Результаты поиска" className="space-y-3">
        {loading && !data ? (
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-[140px] animate-pulse rounded-2xl border border-slate-200 bg-white" />
            ))}
          </div>
        ) : null}

        {data?.doctors?.length ? (
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {visibleDoctors.map((d) => (
              <DoctorCard
                key={d.id}
                doctor={d}
                clinics={data.clinics}
                slots={data.availableSlots}
                onPick={() => setSelectedDoctorId(d.id)}
              />
            ))}
          </div>
        ) : null}

        {data?.ok && data.doctors?.length === 0 && !loading ? (
          <Card>
            <div className="text-base font-semibold">Ничего не найдено</div>
            <div className="mt-1 text-slate-600">Попробуйте другую специальность или измените фильтры.</div>
          </Card>
        ) : null}
      </section>

      <BookingModal
        open={Boolean(selectedDoctor)}
        doctor={selectedDoctor}
        clinics={data?.clinics || []}
        slots={selectedSlots}
        onClose={() => setSelectedDoctorId(null)}
        onBooked={() => {
          setSelectedDoctorId(null);
          runSearch();
        }}
      />
    </section>
  );
}

