import { api } from "../../services/api";

export async function searchDoctors(params) {
  const { data } = await api.get("/search", { params });
  return data;
}

