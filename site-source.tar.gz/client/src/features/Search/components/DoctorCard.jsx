import React, { useMemo } from "react";
import { Heart } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { Card } from "../../../components/Card";
import { Button } from "../../../components/Button";
import { useFavoritesStore } from "../../../stores/favorites.store";

function byTimeAsc(a, b) {
  return new Date(a.slot_time) - new Date(b.slot_time);
}

export function DoctorCard({ doctor, clinics, slots, onPick }) {
  const favoriteIds = useFavoritesStore((s) => s.doctorIds);
  const toggle = useFavoritesStore((s) => s.toggle);
  const isFav = favoriteIds.includes(doctor.id);

  const clinic = useMemo(
    () => (clinics || []).find((c) => c.id === doctor.clinic_id) || null,
    [clinics, doctor.clinic_id]
  );

  const doctorSlots = useMemo(() => {
    return (slots || [])
      .filter((s) => s.doctor_id === doctor.id)
      .slice()
      .sort(byTimeAsc);
  }, [slots, doctor.id]);

  const soonest = doctorSlots[0] || null;
  const typeLabel = clinic?.type === "private" ? "Частная" : clinic?.type === "state" ? "Гос" : null;

  return (
    <Card className="flex flex-col gap-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-base font-semibold text-slate-900">{doctor.full_name}</div>
          <div className="mt-0.5 text-sm text-slate-600">
            {doctor.specialty}
            {doctor.experience ? ` · стаж ${doctor.experience} лет` : ""}
          </div>
          {clinic ? (
            <div className="mt-1 text-sm text-slate-600">
              {clinic.name}
              {typeLabel ? ` · ${typeLabel}` : ""}
              {clinic.rating != null ? ` · ★ ${clinic.rating}` : ""}
            </div>
          ) : null}
        </div>

        <button
          type="button"
          aria-label={isFav ? "Убрать из избранного" : "Добавить в избранное"}
          aria-pressed={isFav}
          className={
            "inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-slate-200 " +
            (isFav ? "bg-rose-50 text-rose-600" : "bg-white text-slate-500 hover:bg-slate-50")
          }
          onClick={() => toggle(doctor.id)}
        >
          <Heart className="h-5 w-5" fill={isFav ? "currentColor" : "none"} />
        </button>
      </div>

      {doctor.bio ? <p className="line-clamp-2 text-sm text-slate-600">{doctor.bio}</p> : null}

      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="text-sm text-slate-600">
          {soonest
            ? `Ближайший слот: ${format(new Date(soonest.slot_time), "d MMM, HH:mm", { locale: ru })}`
            : "Свободных слотов нет"}
        </div>
        <Button
          type="button"
          onClick={onPick}
          disabled={!soonest}
          className="min-h-[44px] sm:w-auto"
        >
          Записаться
        </Button>
      </div>
    </Card>
  );
}
