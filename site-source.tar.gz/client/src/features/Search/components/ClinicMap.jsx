import React, { useEffect, useMemo } from "react";
import { MapContainer, Marker, Popup, TileLayer, useMap } from "react-leaflet";
import L from "leaflet";
import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";

// Vite + Leaflet: стандартные иконки ломаются без явной настройки путей.
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow
});

const MOSCOW = [55.7558, 37.6173];

function FitBounds({ points }) {
  const map = useMap();

  useEffect(() => {
    if (!points.length) {
      map.setView(MOSCOW, 10);
      return;
    }
    if (points.length === 1) {
      map.setView(points[0], 12);
      return;
    }
    map.fitBounds(L.latLngBounds(points), { padding: [28, 28], maxZoom: 13 });
  }, [map, points]);

  return null;
}

export function ClinicMap({ clinics }) {
  const points = useMemo(() => {
    return (clinics || [])
      .map((c) => {
        const lat = c?.coordinates?.lat;
        const lng = c?.coordinates?.lng;
        if (typeof lat !== "number" || typeof lng !== "number") return null;
        return [lat, lng];
      })
      .filter(Boolean);
  }, [clinics]);

  return (
    <MapContainer center={MOSCOW} zoom={10} scrollWheelZoom={false} className="h-full w-full">
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <FitBounds points={points} />
      {(clinics || []).map((c) => {
        const lat = c?.coordinates?.lat;
        const lng = c?.coordinates?.lng;
        if (typeof lat !== "number" || typeof lng !== "number") return null;
        return (
          <Marker key={c.id} position={[lat, lng]}>
            <Popup>
              <div className="text-sm">
                <div className="font-semibold">{c.name}</div>
                {c.rating != null ? <div>Рейтинг: {c.rating}</div> : null}
                {c.address ? <div className="text-slate-600">{c.address}</div> : null}
              </div>
            </Popup>
          </Marker>
        );
      })}
    </MapContainer>
  );
}
