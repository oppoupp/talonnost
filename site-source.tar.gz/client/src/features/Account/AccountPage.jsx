import React, { useEffect, useMemo, useState } from "react";
import { Card } from "../../components/Card";
import { Button } from "../../components/Button";
import { useToast } from "../../components/Toast";
import { useAuthStore } from "../../stores/auth.store";
import { useFavoritesStore } from "../../stores/favorites.store";
import { api } from "../../services/api";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { AuthModal } from "../Auth/AuthModal";
import { searchDoctors } from "../Search/search.service";
import { DoctorCard } from "../Search/components/DoctorCard";
import { BookingModal } from "../Booking/BookingModal";

function isPast(iso) {
  return new Date(iso).getTime() < Date.now();
}

export function AccountPage() {
  const toast = useToast();
  const token = useAuthStore((s) => s.token);
  const user = useAuthStore((s) => s.user);
  const favoriteIds = useFavoritesStore((s) => s.doctorIds);
  const clearFav = useFavoritesStore((s) => s.clear);

  const [authOpen, setAuthOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState([]);
  const [favLoading, setFavLoading] = useState(false);
  const [favData, setFavData] = useState(null);
  const [selectedDoctorId, setSelectedDoctorId] = useState(null);

  async function load() {
    if (!token || !user) return;
    setLoading(true);
    try {
      const { data } = await api.get("/me/appointments");
      if (data?.ok) setItems(data.appointments || []);
    } catch (err) {
      toast.push({
        type: "error",
        title: "Не удалось загрузить записи",
        message: err?.response?.data?.error?.message || "Попробуйте позже"
      });
    } finally {
      setLoading(false);
    }
  }

  async function loadFavorites() {
    if (!favoriteIds.length) {
      setFavData({ ok: true, doctors: [], clinics: [], availableSlots: [] });
      return;
    }
    setFavLoading(true);
    try {
      // Берем все данные через search endpoint, чтобы не плодить отдельные роуты.
      // Фильтрация избранного выполняется на клиенте (по doctorIds).
      const res = await searchDoctors({ q: "" });
      setFavData(res);
    } catch (err) {
      toast.push({
        type: "error",
        title: "Не удалось загрузить избранное",
        message: err?.response?.data?.error?.message || "Попробуйте позже"
      });
    } finally {
      setFavLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, user]);

  useEffect(() => {
    loadFavorites();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [favoriteIds.join("|")]);

  const current = useMemo(() => items.filter((a) => !isPast(a.slot_time)), [items]);
  const past = useMemo(() => items.filter((a) => isPast(a.slot_time)), [items]);

  const selectedDoctor = useMemo(() => {
    const list = favData?.doctors || [];
    return list.find((d) => d.id === selectedDoctorId) || null;
  }, [favData, selectedDoctorId]);

  const selectedSlots = useMemo(() => {
    if (!selectedDoctor || !favData?.availableSlots) return [];
    return favData.availableSlots.filter((s) => s.doctor_id === selectedDoctor.id);
  }, [favData, selectedDoctor]);

  if (!token || !user) {
    return (
      <section className="space-y-3">
        <Card>
          <div className="text-base font-semibold">Личный кабинет</div>
          <div className="mt-1 text-slate-600">
            Чтобы увидеть ваши записи, войдите или зарегистрируйтесь.
          </div>
          <div className="mt-3">
            <Button type="button" onClick={() => setAuthOpen(true)} className="min-h-[44px]">
              Войти
            </Button>
          </div>
        </Card>
        <AuthModal open={authOpen} onClose={() => setAuthOpen(false)} />
      </section>
    );
  }

  return (
    <section className="space-y-4">
      <Card>
        <div className="flex items-center justify-between gap-3">
          <div>
            <div className="text-base font-semibold">Здравствуйте, {user.username}</div>
            <div className="text-sm text-slate-600">{user.email}</div>
          </div>
          <Button variant="secondary" type="button" onClick={load} disabled={loading} className="min-h-[44px]">
            {loading ? "Обновляем…" : "Обновить"}
          </Button>
        </div>
      </Card>

      <section aria-label="Избранные врачи" className="space-y-2">
        <div className="flex items-center justify-between gap-3">
          <div className="text-base font-semibold">Избранное</div>
          <div className="flex items-center gap-2">
            <Button
              variant="secondary"
              type="button"
              onClick={loadFavorites}
              disabled={favLoading}
              className="min-h-[44px]"
            >
              {favLoading ? "Обновляем…" : "Обновить"}
            </Button>
            <Button
              variant="ghost"
              type="button"
              onClick={() => {
                clearFav();
                toast.push({ type: "success", title: "Готово", message: "Избранное очищено" });
              }}
              className="min-h-[44px]"
              disabled={!favoriteIds.length}
            >
              Очистить
            </Button>
          </div>
        </div>

        {!favoriteIds.length ? (
          <Card>
            <div className="text-slate-600">
              В избранном пока пусто. Нажмите сердечко на карточке врача в поиске.
            </div>
          </Card>
        ) : null}

        {favLoading && !favData ? (
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {Array.from({ length: 2 }).map((_, i) => (
              <div key={i} className="h-[140px] animate-pulse rounded-2xl border border-slate-200 bg-white" />
            ))}
          </div>
        ) : null}

        {favData?.doctors?.length ? (
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {(favData.doctors || [])
              .filter((d) => favoriteIds.includes(d.id))
              .map((d) => (
                <DoctorCard
                  key={d.id}
                  doctor={d}
                  clinics={favData.clinics}
                  slots={favData.availableSlots}
                  onPick={() => setSelectedDoctorId(d.id)}
                />
              ))}
          </div>
        ) : null}
      </section>

      <section aria-label="Текущие записи" className="space-y-2">
        <div className="text-base font-semibold">Текущие</div>
        {current.length === 0 && !loading ? (
          <Card>
            <div className="text-slate-600">Пока нет текущих записей.</div>
          </Card>
        ) : null}
        {current.map((a) => (
          <AppointmentRow key={a.id} appt={a} onChanged={load} />
        ))}
      </section>

      <section aria-label="Прошедшие записи" className="space-y-2">
        <div className="text-base font-semibold">Прошедшие</div>
        {past.length === 0 && !loading ? (
          <Card>
            <div className="text-slate-600">Прошедших записей нет.</div>
          </Card>
        ) : null}
        {past.map((a) => (
          <AppointmentRow key={a.id} appt={a} readOnly />
        ))}
      </section>

      <BookingModal
        open={Boolean(selectedDoctor)}
        doctor={selectedDoctor}
        clinics={favData?.clinics || []}
        slots={selectedSlots}
        onClose={() => setSelectedDoctorId(null)}
        onBooked={() => {
          setSelectedDoctorId(null);
          load();
          loadFavorites();
        }}
      />
    </section>
  );
}

function AppointmentRow({ appt, onChanged, readOnly }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);

  async function cancel() {
    setBusy(true);
    try {
      const { data } = await api.post("/me/appointments/cancel", { appointmentId: appt.id });
      if (data?.ok) {
        toast.push({ type: "success", title: "Отменено", message: "Запись освобождена" });
        onChanged?.();
      }
    } catch (err) {
      toast.push({
        type: "error",
        title: "Не удалось отменить",
        message: err?.response?.data?.error?.message || "Попробуйте позже"
      });
    } finally {
      setBusy(false);
    }
  }

  const when = format(new Date(appt.slot_time), "d MMMM yyyy, HH:mm", { locale: ru });

  return (
    <Card className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <div className="text-sm text-slate-600">{when}</div>
        <div className="text-base font-semibold">{appt.doctor?.full_name || "Врач"}</div>
        <div className="text-sm text-slate-600">
          {appt.doctor?.specialty || ""} {appt.clinic ? `• ${appt.clinic.name}` : ""}
        </div>
      </div>
      {!readOnly ? (
        <Button
          variant="secondary"
          type="button"
          onClick={cancel}
          disabled={busy}
          className="min-h-[44px]"
        >
          {busy ? "Отменяем…" : "Отменить"}
        </Button>
      ) : null}
    </Card>
  );
}

