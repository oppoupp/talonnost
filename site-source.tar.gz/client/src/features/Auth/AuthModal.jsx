import React, { useMemo, useState } from "react";
import { Modal } from "../../components/Modal";
import { Input } from "../../components/Input";
import { Button } from "../../components/Button";
import { useAuthStore } from "../../stores/auth.store";
import { useToast } from "../../components/Toast";

export function AuthModal({ open, onClose }) {
  const [mode, setMode] = useState("login"); // login | register
  const authLoading = useAuthStore((s) => s.authLoading);
  const login = useAuthStore((s) => s.login);
  const register = useAuthStore((s) => s.register);
  const toast = useToast();

  const title = useMemo(() => (mode === "login" ? "Вход" : "Регистрация"), [mode]);

  const [form, setForm] = useState({ username: "", email: "", password: "" });
  const [errors, setErrors] = useState({});

  function validate() {
    const e = {};
    if (mode === "register" && form.username.trim().length < 2) e.username = "Минимум 2 символа";
    if (!form.email.includes("@")) e.email = "Введите корректный email";
    if (form.password.length < 8) e.password = "Минимум 8 символов";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function onSubmit(e) {
    e.preventDefault();
    if (!validate()) return;
    try {
      const result =
        mode === "login"
          ? await login({ email: form.email, password: form.password })
          : await register({ username: form.username, email: form.email, password: form.password });

      if (result?.ok) {
        toast.push({ type: "success", title: "Готово", message: "Вы вошли в аккаунт" });
        onClose?.();
      }
    } catch (err) {
      toast.push({
        type: "error",
        title: "Ошибка",
        message: err?.response?.data?.error?.message || "Не удалось выполнить действие"
      });
    }
  }

  return (
    <Modal
      open={open}
      title={title}
      onClose={onClose}
      footer={
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="text-sm text-slate-600">
            {mode === "login" ? "Нет аккаунта?" : "Уже есть аккаунт?"}{" "}
            <button
              type="button"
              className="min-h-[44px] rounded-xl px-2 font-semibold text-primary-600 hover:bg-slate-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-600 focus-visible:ring-offset-2"
              onClick={() => setMode(mode === "login" ? "register" : "login")}
            >
              {mode === "login" ? "Регистрация" : "Войти"}
            </button>
          </div>
          <Button type="submit" form="authForm" disabled={authLoading} className="min-h-[44px]">
            {authLoading ? "Подождите…" : mode === "login" ? "Войти" : "Создать аккаунт"}
          </Button>
        </div>
      }
    >
      <form id="authForm" onSubmit={onSubmit} className="space-y-3">
        {mode === "register" ? (
          <Input
            label="Имя"
            name="username"
            autoComplete="username"
            value={form.username}
            onChange={(e) => setForm((p) => ({ ...p, username: e.target.value }))}
            error={errors.username}
          />
        ) : null}
        <Input
          label="Email"
          name="email"
          autoComplete="email"
          inputMode="email"
          value={form.email}
          onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))}
          error={errors.email}
        />
        <Input
          label="Пароль"
          name="password"
          type="password"
          autoComplete={mode === "login" ? "current-password" : "new-password"}
          value={form.password}
          onChange={(e) => setForm((p) => ({ ...p, password: e.target.value }))}
          error={errors.password}
        />
      </form>
    </Modal>
  );
}

