import React, { useMemo, useState } from "react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { Modal } from "../../components/Modal";
import { Button } from "../../components/Button";
import { useToast } from "../../components/Toast";
import { useAuthStore } from "../../stores/auth.store";
import { api } from "../../services/api";
import { AuthModal } from "../Auth/AuthModal";

function byTimeAsc(a, b) {
  return new Date(a.slot_time) - new Date(b.slot_time);
}

export function BookingModal({ open, onClose, doctor, clinics, slots, onBooked }) {
  const toast = useToast();
  const token = useAuthStore((s) => s.token);
  const user = useAuthStore((s) => s.user);

  const clinic = useMemo(() => {
    if (!doctor) return null;
    return clinics?.find((c) => c.id === doctor.clinic_id) || null;
  }, [doctor, clinics]);

  const sortedSlots = useMemo(() => (slots || []).slice().sort(byTimeAsc), [slots]);

  const [appointmentId, setAppointmentId] = useState(null);
  const [step, setStep] = useState(1); // 1 select time, 2 confirm
  const [busy, setBusy] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);

  const selectedSlot = useMemo(
    () => sortedSlots.find((s) => s.id === appointmentId) || null,
    [sortedSlots, appointmentId]
  );

  function reset() {
    setAppointmentId(null);
    setStep(1);
    setBusy(false);
  }

  function closeAll() {
    reset();
    onClose?.();
  }

  async function confirm() {
    if (!selectedSlot) return;
    if (!token || !user) {
      setAuthOpen(true);
      return;
    }
    setBusy(true);
    try {
      const { data } = await api.post("/me/appointments/book", { appointmentId: selectedSlot.id });
      if (data?.ok) {
        toast.push({ type: "success", title: "Запись подтверждена", message: "Мы сохранили вашу запись в кабинете" });
        closeAll();
        onBooked?.();
      }
    } catch (err) {
      const code = err?.response?.data?.error?.code;
      toast.push({
        type: "error",
        title: "Не удалось записаться",
        message:
          code === "SLOT_TAKEN"
            ? "Слот уже занят. Обновите список и выберите другое время."
            : err?.response?.data?.error?.message || "Попробуйте еще раз"
      });
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <Modal
        open={open}
        onClose={closeAll}
        title={doctor ? `Запись: ${doctor.specialty}` : "Запись"}
        footer={
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <Button
              type="button"
              variant="secondary"
              onClick={() => (step === 1 ? closeAll() : setStep(1))}
              className="min-h-[44px]"
            >
              {step === 1 ? "Отмена" : "Назад"}
            </Button>
            <Button
              type="button"
              onClick={() => (step === 1 ? setStep(2) : confirm())}
              disabled={step === 1 ? !appointmentId : busy}
              className="min-h-[44px]"
            >
              {step === 1 ? "Продолжить" : busy ? "Записываем…" : "Подтвердить"}
            </Button>
          </div>
        }
      >
        {doctor ? (
          <div className="space-y-3">
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-3">
              <div className="text-sm text-slate-700">
                <div className="font-semibold">{doctor.full_name}</div>
                <div className="text-slate-600">{clinic ? clinic.name : "Клиника"}</div>
              </div>
            </div>

            {step === 1 ? (
              <div>
                <div className="mb-2 text-sm font-semibold">Шаг 2/3: выберите время</div>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {sortedSlots.map((s) => {
                    const label = format(new Date(s.slot_time), "d MMM, HH:mm", { locale: ru });
                    const active = s.id === appointmentId;
                    return (
                      <button
                        key={s.id}
                        type="button"
                        className={
                          "min-h-[44px] rounded-xl border px-3 py-2 text-sm font-medium " +
                          (active
                            ? "border-primary-600 bg-blue-50 text-slate-900"
                            : "border-slate-200 bg-white hover:bg-slate-50")
                        }
                        onClick={() => setAppointmentId(s.id)}
                      >
                        {label}
                      </button>
                    );
                  })}
                </div>
                {sortedSlots.length === 0 ? (
                  <div className="text-sm text-slate-600">Нет доступных слотов. Попробуйте другой день.</div>
                ) : null}
              </div>
            ) : (
              <div>
                <div className="mb-2 text-sm font-semibold">Шаг 3/3: подтверждение</div>
                {selectedSlot ? (
                  <div className="rounded-2xl border border-slate-200 bg-white p-3 text-sm">
                    <div className="text-slate-600">Вы записываетесь на:</div>
                    <div className="mt-1 font-semibold">
                      {format(new Date(selectedSlot.slot_time), "EEEE, d MMMM, HH:mm", { locale: ru })}
                    </div>
                  </div>
                ) : (
                  <div className="text-sm text-slate-600">Выберите время на предыдущем шаге.</div>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="text-sm text-slate-600">Выберите врача.</div>
        )}
      </Modal>

      <AuthModal
        open={authOpen}
        onClose={() => {
          setAuthOpen(false);
          toast.push({ type: "info", title: "Почти готово", message: "Теперь можно подтвердить запись" });
        }}
      />
    </>
  );
}

